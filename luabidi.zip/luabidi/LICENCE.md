# MIT Licence

Copyright (c) Vafa Khalighi 2009, Arthur Reutenauer 2013, 2019, Jürgen Spitzmüller 2019.

The licence for all files within this package is (the MIT
licence)[https://opensource.org/licenses/MIT] unless otherwise noted.
