# luabidi
Luabidi is an attempt to offer the same functionality for LuaTeX as bidi
does for XeTeX.

## CTAN Package
https://www.ctan.org/pkg/luabidi

Copyright (c) Vafa Khalighi 2009, Arthur Reutenauer 2013, 2019-2023,
Jürgen Spitzmüller 2019-2023

Except for luabidi.sty, all files in this package are licensed under the terms
of the MIT licence in the wording of the Open Source Initiative
(https://opensource.org/licenses/MIT).  The file luabidi.sty is licensed under
the LaTeX Project Public License (https://www.latex-project.org/lppl/), either
version 1.3c or, at your option, any later version.
