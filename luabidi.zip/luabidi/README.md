# luabidi
Luabidi is an attempt to offer the same functionality for LuaTeX as bidi
does for XeTeX.

## CTAN Package
https://www.ctan.org/pkg/luabidi

Copyright (c) Vafa Khalighi 2009, Arthur Reutenauer 2013, 2019, Jürgen Spitzmüller 2019
